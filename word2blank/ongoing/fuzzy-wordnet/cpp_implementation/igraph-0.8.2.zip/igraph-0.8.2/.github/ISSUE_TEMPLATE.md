Please **do not** use the issue tracker for personal support requests -- use our
[Discourse group](https://igraph.discourse.group) instead.

Make sure that these boxes are checked before submitting your issue -- thank you!

- [ ] This issue is for the C core of igraph.
- [ ] This issue is a bug report or a feature request, not a support question.

